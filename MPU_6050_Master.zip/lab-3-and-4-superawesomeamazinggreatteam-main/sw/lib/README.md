# Lib Folder

Any drivers that you write for this lab, please put them in this folder. It'll
make it easier for TAs to evaluate. An example driver is presented for you to
show you what the syntax style should look like.
